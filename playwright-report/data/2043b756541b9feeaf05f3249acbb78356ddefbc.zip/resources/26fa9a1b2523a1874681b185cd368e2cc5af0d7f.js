(function () {
	'use strict';



})();
